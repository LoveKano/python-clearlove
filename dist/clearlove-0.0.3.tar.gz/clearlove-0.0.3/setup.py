from setuptools import setup,find_packages
setup(
	name='clearlove',
	version='0.0.3',
	description='an demo',
	author='lovekano',
	author_email='814953866@qq.com',
	include_package_data=True,
	packages=find_packages(),
	install_requires=[''],
	license='MIT Licence',
	zip_safe=False,
	)