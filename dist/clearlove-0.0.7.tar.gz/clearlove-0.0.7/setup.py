from distutils.core import setup
VERSION='0.0.7'
setup(
	name='clearlove',
	version=VERSION,
	description='I will prove that I am the best jungle, no ,djangoer in the world',
	author='lovekano',
	author_email='814953866@qq.com',
	include_package_data=True,
	packages=['clearlove'],
	install_requires=[''],
	license='MIT Licence',
	zip_safe=False,
	)