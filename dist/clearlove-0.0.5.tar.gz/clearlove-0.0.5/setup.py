from distutils.core import setup
setup(
	name='clearlove',
	version='0.0.5',
	description='I will prove that I am the best jungle, no ,djangoer in the world',
	author='lovekano',
	author_email='814953866@qq.com',
	include_package_data=True,
	packages=['clearlove'],
	install_requires=[''],
	license='MIT Licence',
	zip_safe=False,
	)