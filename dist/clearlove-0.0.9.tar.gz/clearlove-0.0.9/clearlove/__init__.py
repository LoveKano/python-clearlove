def clearlove():
	print("I will prove that I am the best jungle in the world")