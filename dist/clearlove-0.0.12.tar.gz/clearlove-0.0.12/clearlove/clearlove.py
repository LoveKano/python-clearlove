def leesin():
    print("泰拳警告")
