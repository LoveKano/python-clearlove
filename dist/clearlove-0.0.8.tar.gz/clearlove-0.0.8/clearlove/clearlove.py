def taiquanjinggao():
	print("泰拳警告")

